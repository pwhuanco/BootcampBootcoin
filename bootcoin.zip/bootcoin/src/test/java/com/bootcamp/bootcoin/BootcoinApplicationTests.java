package com.bootcamp.bootcoin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcoinApplicationTests {

	@Test
	void contextLoads() {
	}

}
